# CSE471_Project: Rentorium

## Module 1: User Authentication
- Sign in, Sign out 
- Sign up
- Profile Management (View Profile, Edit profile, Delete Profile) 
- Password Reset

## Module 2: Property Information 
- Property List, View Posted Property
- Filter, Search, Review
- Add Property
- Property Management (Update, Delete, Documents) 
- Agent Dashboard (Approval)
- Customer Support (Feedback form)
