"""rentorium URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from django.conf import settings


from django.conf import settings
from django.conf.urls.static import static


from login import views




from pages.views import home_view, user_profile_view, products_view, about_view
from login.views import (
    product_detail_view,
    product_create_view,
    dynamic_lookup_view,
    item_deletion_view,
    items_list_view,
    delete_item,get_items,
    make_payment_view,
    contact_view
)

urlpatterns = [
    path('', include(('user_login.urls', 'user_login'), 'user_login')),
    path('items/<int:id>', views.items),
    path('items/<int:item_id>/', dynamic_lookup_view, name='item-detail'),
    path('items/<int:item_id>/delete/', item_deletion_view, name='item-delete'),
    path('items/<int:item_id>/delete/', delete_item, {'redirect_url': 'items-list'}, name='item-delete'),  # No model specified
    path('items/', items_list_view),
    # path('', home_view),
    path('home/', home_view, name='home'),
    path('profile/', user_profile_view),
    path('products/', products_view),
    path('create/', product_create_view),
    path('contact/', contact_view),
    path('item_view/', product_detail_view),
    path('about/', about_view),
    path('admin/', admin.site.urls),
    path('get-items/', get_items, name='get-items'),
    path('get_subcategories/', views.get_subcategories, name='get_subcategories'),
    path('get-items/', get_items, name='get-items'),
    path('items/<int:item_id>/make_payment/', make_payment_view, name='make_payment'),

] 


if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL , document_root = settings.MEDIA_ROOT)
