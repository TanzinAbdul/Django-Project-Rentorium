from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.


def home_view(request, *args, **kwargs):
    # return HttpResponse('<h1>Rentorium</h1>')
    return render(request, 'home.html', {})


def contact_view(request, *args, **kwargs):
    my_context = {'context_title': 'This is the contact view',
                  'phone_number': '+8801795-064368',
                  'coverage_areas': ['Dhaka', 'Chattogram', 'Barishal', 'Rajshahi', 'Khulna', 'Sylhet', 'Rangpur']}
    return render(request, 'contact.html', my_context)


def products_view(request, *args, **kwargs):
    return HttpResponse('<h1>Products</h1>')


def user_profile_view(request, *args, **kwargs):
    return HttpResponse('<h1>User Profile</h1>')


def about_view(request, *args, **kwargs):
    my_context = {}
    return render(request, 'about.html', my_context)
