from django.urls import path, include
from .views import authView, user_post


urlpatterns = [
 path("create/", user_post, name="user_post"),
 path("signup/", authView, name="authView"),
 path("accounts/", include("django.contrib.auth.urls")),
]
