from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.decorators import login_required
from login.templates import products
from login.forms import ProductForm


@login_required
def user_post(request):
    form = ProductForm(request.POST, request.FILES)
    if form.is_valid():
        form.save()

        form = ProductForm()

    context = {'form': form}
    return render(request, "products/product_create.html", context)



def authView(request):

     if request.method == "POST":
         form = UserCreationForm(request.POST or None)
         if form.is_valid():
             form.save()
             return redirect("user_login:login")
     else:
      form = UserCreationForm()
     return render(request, "registration/signup.html", {"form": form})