from django.apps import AppConfig


class UserLoginConfig(AppConfig):
    name = 'user_login'
