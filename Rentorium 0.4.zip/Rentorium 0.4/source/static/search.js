// search.js
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('search-form');
    const input = document.getElementById('search-input');
    const resultsDiv = document.getElementById('search-results');

    form.addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent the form from submitting normally

        const searchText = input.value.toLowerCase();
        const paragraphs = document.querySelectorAll('p'); // Change selector as needed

        let searchResults = '';

        paragraphs.forEach(function(paragraph) {
            const text = paragraph.textContent.toLowerCase();
            if (text.includes(searchText)) {
                searchResults += `<p>${paragraph.innerHTML}</p>`;
            }
        });

        resultsDiv.innerHTML = searchResults;
    });
});
