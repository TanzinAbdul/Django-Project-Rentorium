from django.contrib import admin
from .models import Item, Contact

class ItemAdmin(admin.ModelAdmin):
    list_display = ['title', 'description', 'price', 'new', 'product_image']

    def display_image(self, obj):
        return obj.product_image.url if obj.product_image else None

    display_image.short_description = 'Image'

class ContactAdmin(admin.ModelAdmin):
    list_display = ['name', 'email', 'message']

admin.site.register(Item, ItemAdmin)
admin.site.register(Contact, ContactAdmin)
