from django import forms
from .models import Item
from .models import Contact


from django import forms
from .models import Item


class ProductForm(forms.ModelForm):
    class Meta:
        model = Item
        fields = ['title', 'description', 'price', 'new', 'product_image']



class RawProductForm(forms.Form):
    title = forms.CharField(label='', widget=forms.TextInput(attrs={'placeholder': 'Post Title'}))
    description = forms.CharField(label='', widget=forms.Textarea(attrs={
        'placeholder': 'Item Description',
        'class': 'new-class-name two',
        'id': 'my-id-for-textarea',
        'rows': 15,
        'cols': 70, 'product_image': '',}))

    price = forms.DecimalField(initial=0)
    new = forms.BooleanField(required=False)
    category = forms.CharField(label='', widget=forms.TextInput(attrs={'placeholder': 'Category'}))




class ContactForm(forms.ModelForm):
    name = forms.CharField(label='', widget=forms.TextInput(attrs={'placeholder': 'Your Name:'}))
    message = forms.CharField(label='', widget=forms.Textarea(attrs={
        'placeholder': 'Write your message here',
        'class': 'new-class-name two',
        'id': 'my-id-for-textarea',
        'rows': 15,
        'cols': 70}))

    
    email = forms.EmailField(label='', widget=forms.TextInput(attrs={'placeholder': 'Your Emai:'}))
    class Meta:
        model = Contact
        fields = ['name', 'email', 'message']

    # class Meta:
    #     model = Contact
    #     fields = ['name', 'email', 'message']





class RawContactForm(forms.Form):
    # name = forms.CharField()
    # email = forms.EmailField()
    # message = forms.CharField()

    title = forms.CharField(label='', widget=forms.TextInput(attrs={'placeholder': 'Post Title'}))
    description = forms.CharField(label='', widget=forms.Textarea(attrs={
        'placeholder': 'Item Description',
        'class': 'new-class-name two',
        'id': 'my-id-for-textarea',
        'rows': 15,
        'cols': 70, 'product_image': '',}))

    price = forms.DecimalField(initial=0)
    new = forms.BooleanField(required=False)
    category = forms.CharField(label='', widget=forms.TextInput(attrs={'placeholder': 'Category'}))
