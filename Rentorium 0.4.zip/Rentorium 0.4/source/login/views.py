from django.http import Http404, JsonResponse
from django.shortcuts import render, get_object_or_404, redirect
from .models import Item, Category  # Import Category model
from .forms import ProductForm, RawProductForm
from .forms import ContactForm, RawContactForm

from .models import Contact
# Remove duplicate import statement
# from login.models import Item

def delete_item(request, model, item_id, redirect_url):
    if request.method == 'POST':
        item = get_object_or_404(model, id=item_id)
        item.delete()
        return redirect(redirect_url)
    else:
        # Handle GET request if needed
        pass

def product_detail_view(request):
    obj = Item.objects.get(id=1)
    uploaded_image = None
    if request.method == 'POST' and request.FILES.get('image'):
        uploaded_image = request.FILES['image']
        # Save the uploaded image to the database or filesystem
        # Here, you can process and save the image as per your requirements
    context = {
        'object': obj,
        'uploaded_image': uploaded_image
    }
    return render(request, "products/item_details.html", context)


def dynamic_lookup_view(request, item_id):
    try:
        obj = Item.objects.get(id=item_id)
    except Item.DoesNotExist:
        raise Http404

    context = {'object': obj}
    return render(request, 'products/item_details.html', context)

def item_deletion_view(request, item_id):
    obj = get_object_or_404(Item, id=item_id)
    if request.method == 'POST':
        obj.delete()
        return redirect('../../')
    context = {'object': obj}
    return render(request, 'products/item_deletion.html', context)

def items_list_view(request):
    queryset = Item.objects.all()
    context = {'object_list': queryset}
    return render(request, 'products/items_list.html', context)

def items(request, item_id):
    items = Item.objects.get(pk=item_id)

    if items is not None:
        return render(request, 'products/items.html', {'items': items})
    else:
        raise Http404('Item does not exist')

def get_subcategories(request):
    # Define Subcategory model and filter subcategories accordingly
    # subcategories = Subcategory.objects.filter(category_id=category_id).values('id', 'name')
    return JsonResponse({'message': 'Subcategories not implemented'}, status=501)

def get_items(request):
    items = Item.objects.all()
    data = list(items.values())
    return JsonResponse(data, safe=False)


def make_payment_view(request, item_id):
    try:
        obj = Item.objects.get(id=item_id)
    except Item.DoesNotExist:
        raise Http404

    context = {'object': obj}

    return render(request, 'products/make_payment.html' , context)


def product_create_view(request):
    form = ProductForm(request.POST, request.FILES)
    if form.is_valid():
        form.save()

        form = ProductForm()

    context = {'form': form}
    return render(request, "products/product_create.html", context)


def contact_view(request):
    #categories = Category.objects.all()
    my_form = ContactForm(request.POST or None)

    #if request.method == 'POST':
        
    if my_form .is_valid():
        my_form .save()
        my_form=ContactForm()
        # Redirect to a success page or home page after successful form submission
        return redirect('home')
    # else:
    #     form = ContactForm()
    
    return render(request, 'products/contact.html', {'form': my_form })