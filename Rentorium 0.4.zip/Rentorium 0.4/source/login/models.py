from django.db import models
from django.urls import reverse


# Create your models here.


class Guest(models.Model):
    user_name = models.CharField(max_length=15)
    user_password = models.CharField(max_length=20)
    id = models.AutoField(primary_key=True)


class Item(models.Model):
    id = models.BigAutoField(primary_key=True)
    title = models.CharField(max_length=50)  # max length required
    description = models.TextField()
    price = models.DecimalField(decimal_places=2, max_digits=12)
    new = models.BooleanField()
    # category = models.CharField(max_length=50,default='uncategorized')

    product_image = models.ImageField(upload_to='login/files/covers', null=True, blank=True)

    def get_absolute_url(self):
        return reverse('item-detail', kwargs={"item_id": self.id})


class Category(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name


class Subcategory(models.Model):
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)


class Contact(models.Model):
    id = models.BigAutoField(primary_key=True)
    name = models.CharField(max_length=100)
    email = models.EmailField()
    message = models.CharField(max_length=100)
